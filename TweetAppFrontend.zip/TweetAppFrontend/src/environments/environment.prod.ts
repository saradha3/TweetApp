export const environment = {
  production: true,
  baseUrl:"http://localhost:8096/api/v1.0/tweets/"
};
