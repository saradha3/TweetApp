package com.tweetapp2.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.tweetapp2.constants.ServiceConstants;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@Document(collection = ServiceConstants.COMMENT_COLLECTION_TABLE)
public class Comment {
	public Comment() {
		super();
	}
	@Id
	String commentId;
	String postId;
	String author;
	String commentMessage;
	Date dateOfComment;
}