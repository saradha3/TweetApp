package com.tweetapp2.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.tweetapp2.constants.ServiceConstants;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@Document(collection = ServiceConstants.POST_COLLECTION_TABLE)
public class Post {
	public Post() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Id
	String id;
	String author;
	String postMessage;
	String hasTag;
	Date dateOfPost;
	Long likesCount;
}